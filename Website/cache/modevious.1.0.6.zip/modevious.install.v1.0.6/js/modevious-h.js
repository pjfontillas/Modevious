var $j = jQuery.noConflict();
// core Modevious libraries
include('/js/lib/tools.expose-1.0.5.js');
include('/js/lib/jquery.autoMouseOver.js');
include('/js/lib/jquery.pnotify.js');
include('/js/lib/jquery.dumbcrossfade-1.2.min.js');

// define run-time event functions
addLoadEvent(function initExpose() {
	$j(".expose").click(function(){
		$j(this).expose({api: true, closeOnEsc: false, zIndex: 498}).load();
	});
});

addLoadEvent(function initMouseOver() {
	$j(".mouse-over").mouseover(function(){
		$j(this).autoMouseOver();
	});
});

addLoadEvent(function initDCF() {
	$j('.dumbCrossFade .dumbItem').dumbCrossFade();
});

