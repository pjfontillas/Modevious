var $j = jQuery.noConflict();

// core Modevious libraries
$c.add2Lib('/js/lib/prototype.js');
$c.add2Lib('/js/lib/jquery-1.3.2.min.js');
$c.add2Lib('/js/lib/jquery-ui-1.7.2.custom.min.js');
$c.include('/js/lib/tools.expose-1.0.5.js');
$c.include('/js/lib/jquery.autoMouseOver.js');
$c.include('/js/lib/jquery.pnotify.js');
$c.include('/js/lib/jquery.dumbcrossfade-1.2.min.js');

// core CSS
$c.include('/css/cupertino/jquery-ui-1.7.2.custom.css');
$c.include('/css/jquery.pnotify.default.css');
$c.include('/css/dumbcrossfade.css');

// define run-time event functions
$c.addLoadEvent(function () {
	// initialize jQuery UI
	$j('.tabs').tabs();
	$j('.accordion').accordion({ header: 'h3' });

	// initialize Expose elements
	$j('.expose').click(function(){
		$j(this).expose({api: true, closeOnEsc: false, zIndex: 10001}).load();
	});

	// initialize AutoMouseOver elements
	$j('.mouse-over').autoMouseOver();

	// initialize DumbCrossFade elements
	$j('.dumbCrossFade .dumbItem').dumbCrossFade();

	// initialize email address de-obfuscation
	$c.showEmail();
});